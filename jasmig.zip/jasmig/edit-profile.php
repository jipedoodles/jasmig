<?php require '_database/database.php'; ?>
<?php include 'components/authentication.php' ?>
<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/nav/nav.php' ?>   

<?php
	$sql = "SELECT * FROM users WHERE username = '$username'";
	$result = mysqli_query($database,$sql) or die(mysqli_error($database));
	$rws = mysqli_fetch_array($result);
?>

<?php include 'controllers/form/edit-profile-form.php' ?>
<?php include 'components/session-check-index.php' ?>
<?php include 'controllers/base/head.php' ?>

<div style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
  <a href="http://www.jasmig.net"><img src="userfiles/avatars/logo1.png"></a>
  <h3>Project Performance Monitoring System</h3>
    <h5 style="color:#F70566;">Log In</h5>
      <form role="form" action="components/login-process.php" method="post" name="login" style="font-family: FontAwesome;">
        <div class="form-group">
          <input type="text" class="form-control" id="inputUsernameEmail" name="username" placeholder="Username" style="border: 1px solid; text-align: left;" autofocus>
        </div>

        <div class="form-group" style="position: relative;">
          <input type="password" class="form-control" id="inputPassword" name="password" placeholder="Password" style="border: 1px solid; text-align: left;">
          <button type="button" class="btn btn btn-primary ladda-button" onclick="showpass()" style="position: absolute; right: 0; top: 0;">&#xf070;</button>
        </div>
          <button type="submit" class="btn btn btn-primary ladda-button" data-style="zoom-in" value="Sign In" name="login_button" alignment=center>
            Login  
          </button>
      </form>
</div>
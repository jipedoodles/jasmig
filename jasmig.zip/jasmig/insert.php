<?php  include '_database/database.php' ?>
<?php
	/*
	$projid=$_REQUEST['projid'];
    $projname=$_REQUEST['projname'];
    $projmcw=$_REQUEST['projmcw'];
    $projdatenow=$_REQUEST['projdatenow'];
    $projweather=$_REQUEST['projweather'];
    $projchecker=$_REQUEST['projchecker'];
	*/

    $dlitem=$_REQUEST['dlitem'];
    $dlquantity=$_REQUEST['dlquantity'];
    $dlintended=$_REQUEST['dlintended'];
    $dlremarka=$_REQUEST['dlremarka'];
?>

<?php
	$sql = "INSERT INTO deliveries (projid, projname, projmcw, dlitem, dlquantity, dlintended, dlremarka) VALUES('$a', '$b', '$c', '$dlitem', '$dlquantity', '$dlintended', '$dlremarka')";  
	if(mysqli_query($database, $sql))  
	{  
    	echo 'Data Inserted';  
	}  
?>
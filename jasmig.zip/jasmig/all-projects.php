<?php include 'components/authentication.php' ?>     
<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/nav/nav.php' ?>  
<?php include '_database/database.php'; ?>

<?php
    $user = $_SESSION['username'];
    $sql = "SELECT * FROM users WHERE username ='$user'";
    $result = mysqli_query($database, $sql);
    $row = mysqli_fetch_array($result);
    ${'a' . 'b' . 'c'} = $row['first_name'] ." ". $row['middle_name'] ." ". $row['last_name'];
?>
<div class="col-md-12" id="parent">
    <div class="table-responsive" id="child" style="padding: 10px 5px 5px 5px;">
        <table class="table table-striped table-bordered">
            <tr>
                <th id="proj"><a href="all-projects.php?id=projid" id="projid">Project ID</a></th>
                <th id="proj"><a href="all-projects.php?id=projname" id="projname">Project Name</a></th>
                <th id="proj"><a href="all-projects.php?id=projclient" id="projclient">Client</a></th>
                <th id="proj"><a href="all-projects.php?id=projmanager" id="projmanager">Project Manager</a></th>
                <th id="proj"><a href="all-projects.php?id=projchecker" id="projchecker">Checker</a></th>
                <th id="proj"><a href="all-projects.php?id=projengineer" id="projengineer">Site Engineer</a></th>
                <th id="proj"><a href="all-projects.php?id=projbudget" id="projbudget">Budget</a></th>
                <th id="proj"><a href="all-projects.php?id=projlocation" id="projlocation">Location</a></th>
                <th id="proj"><a href="all-projects.php?id=projmcw" id="projmcw">Major Categories of Work</a></th>
                <th id="proj"><a href="all-projects.php?id=projdimension" id="projdimension">Dimensions</a></th>
                <th id="proj"><a href="all-projects.php?id=projstart" id="projstart">Started</a></th>
                <th id="proj"><a href="all-projects.php?id=projend" id="projend">Target End</a></th>
                <th id="proj"><a href="all-projects.php?id=projdate_added" id="projdate_added">Date Added</a></th>
            </tr>
<?php
    
    if (isset($_GET['id'])) {
        $id = $_GET["id"];

        if($_GET['id']=='projname') {
            $id = "projname";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projid') {
            $id = "projid";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projclient') {
            $id = "projclient";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projmanager') {
            $id="projmanager";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projchecker') {
            $id="projchecker";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projengineer') {
            $id="projengineer";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projbudget') {
            $id="projbudget";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projlocation') {
            $id="projlocation";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projmcw') {
            $id="projmcw";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projdimension') {
            $id="projdimension";
            $where = "ORDER BY  $id";
        }
        elseif($_GET['id']=='projstart') {
            $id="projstart";
            $where = "ORDER BY  $id DESC";
        }
        elseif($_GET['id']=='projend') {
            $id="projend";
            $where = "ORDER BY  $id ASC";
        }
        elseif($_GET['id']=='projdate_added') {
            $id="projdate_added";
            $where = "ORDER BY  $id DESC";
        }
    }

    $sql = "SELECT * FROM project WHERE projend_actual != '0000-00-00'" . $where;
    $result = mysqli_query($database,$sql) or die(mysqli_error($database));
    while($rws = mysqli_fetch_array($result)){ 
?>
<?php  
    echo '
        <tr data-href="project.php?projid='.$rws["projid"].'&projmcw='.$rws["projmcw"].'">
            <td id="proj">'.$rws["projid"].'</td>
            <td id="proj">'.$rws["projname"].'</td>
            <td id="proj">'.$rws["projclient"].'</td>
            <td id="proj">'.$rws["projmanager"].'</td>
            <td id="proj">'.$rws["projchecker"].'</td>
            <td id="proj">'.$rws["projengineer"].'</td>
            <td id="proj">Php '
?>
<?php
    echo number_format($rws["projbudget"],2);
?>
<?php
    echo
           '</td>
            <td id="proj">'.$rws["projlocation"].'</td>
            <td id="proj">'.$rws["projmcw"].'</td>
            <td id="proj">'.$rws["projdimension"].'</td>
            <td id="proj">'.$rws["projstart"].'</td>
            <td id="proj">'.$rws["projend"].'</td>
            <td id="proj">'.$rws["projdate_added"].'</td>
        </tr>
       '
?>
 <?php } ?>

<?php include 'components/authentication.php' ?>     
<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/base/style.php' ?>
<?php include 'controllers/nav/nav.php' ?> 

<br>
<?php
    $user = $_SESSION['username'];
    $sql = "SELECT * FROM users WHERE username ='$user'";
    $result = mysqli_query($database, $sql);
    $row = mysqli_fetch_array($result);

    if ($row['position'] == "head manager") {
        include 'backHM.php';
    }
    if ($row['position'] == "checker") {
        include 'backCC.php';
    }
    if ($row['position'] == "project engineer") {
        include 'backPE.php';
    }
    if ($row['position'] == "purchasing officer") {
        include 'backPO.php';
    }
    if ($row['position'] == "client") {
        include 'backCL.php';
    }
?>
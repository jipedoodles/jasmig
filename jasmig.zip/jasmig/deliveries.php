<?php include 'components/authentication.php' ?> 
<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/base/style.php' ?>
<?php include 'controllers/nav/nav.php' ?>
<?php require '_database/database.php' ?>

<?php
    $url = 'http://'.$_SERVER['REQUEST_URI'];
    $url = urldecode($url);
    $id = substr($url, strrpos($url, '?') + 1);

    $id1 = substr($id, strrpos($id, '=') - 16, 8);  //projid
    $id2 = substr($id, strrpos($id, '=') + 1);      //projmcw

    $sql1 = "SELECT * FROM project WHERE projid ='$id1' && projmcw = '$id2'";
    $result1 = mysqli_query($database, $sql1);
    $row1 = mysqli_fetch_array($result1);
    $a = $row1['projid'];
    $b = $row1['projname'];
    $c = $row1['projmcw'];
    
    $sql2 = "SELECT * FROM project WHERE projid = '$a' && projname = '$b' && projmcw = '$c'";
    $result2 = mysqli_query($database, $sql2);
    $row2 = mysqli_fetch_array($result2);

?>

<?php include 'controllers/form/deliveries.php' ?>
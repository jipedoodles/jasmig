<?php
    session_start();
    include '../_database/database.php';
    if(isset($_REQUEST['submit'])){

        $projid=$_POST['projid'];
        $projname=$_POST['projname'];
        $projmcw=$_POST['projmcw'];

    	$s = "INSERT INTO deliveries (projid, projname, projmcw, dlitem, dlquantity, dlintended, dlremarka) VALUES";

    	for($i=0;$i<$_POST['numbers'];$i++) {
    		$s .="('$projid','$projname','$projmcw','".$_POST['dlitem'][$i]."','".$_POST['dlquantity'][$i]."','".$_POST['dlintended'][$i]."','".$_POST['dlremarka'][$i]."'),";
    	}
    	$s = rtrim($s,",");
    	mysqli_query($database,$s) or die(mysqli_error($database));
    	$d = "DELETE FROM deliveries WHERE dlitem = ''";
    	mysqli_query($database,$d) or die(mysqli_error($database));

        header('location:../requisition.php?projid='.$projid.'&projmcw='.$projmcw.'');
    }
?>
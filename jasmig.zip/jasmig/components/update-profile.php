<?php require '../_database/database.php' ?> 

<?php
    ini_set("display_errors",1);
    session_start();
    $temp=$_SESSION['username'];
    $sql="SELECT id FROM users where username ='$temp'";
    $result = mysqli_query($database, $sql);
    $row = mysqli_fetch_array($result);
    $id = $row['id'];
    $result = mysqli_query($database,"SELECT * FROM users WHERE id = '$id'");

    if(isset($_POST)){
        $Destination = '../userfiles/avatars';
        if(!isset($_FILES['ImageFile']) || !is_uploaded_file($_FILES['ImageFile']['tmp_name'])){
            $NewImageName= 'default.png';
            move_uploaded_file($_FILES['ImageFile']['tmp_name'], "$Destination/$NewImageName");
        }
        else{
            $RandomNum   = rand(0, 9999999999);
            $ImageName = str_replace(' ','-',strtolower($_FILES['ImageFile']['name']));
            $ImageType = $_FILES['ImageFile']['type'];
            $ImageExt = substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt = str_replace('.','',$ImageExt);
            $ImageName = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName = $ImageName.'-'.$RandomNum.'.'.$ImageExt;
            move_uploaded_file($_FILES['ImageFile']['tmp_name'], "$Destination/$NewImageName");
        }
        $sql1="UPDATE users SET avatar='$NewImageName' WHERE id = '$id'";
        $sql2="INSERT INTO users (avatar) VALUES ('$NewImageName') WHERE id = '$id'";
        $result = mysqli_query($database,"SELECT * FROM users WHERE id = '$id'");
        if( mysqli_num_rows($result) > 0) {
            if(!empty($_FILES['ImageFile']['name'])){
                mysqli_query($database,$sql1)or die(mysqli_error($database));
                header("location:../edit-profile.php?username=$temp");
            }
        } 
        else {
            mysqli_query($database,$sql2)or die(mysqli_error($database));
            header("location:../edit-profile.php?username=$temp");
        } 
        $username=$_REQUEST['username'];
        $first_name=$_REQUEST['first_name'];
        $middle_name=$_REQUEST['middle_name'];
        $last_name=$_REQUEST['last_name'];
        $email=$_REQUEST['email'];
        $phone=$_REQUEST['phone'];
        $password=$_REQUEST['password'];
        $address=$_REQUEST['address'];
        $client=$_REQUEST['client'];
        $offadd=$_REQUEST['offadd'];

        if ( $client != "") {
            $sql3="UPDATE users SET username='$username',first_name='$first_name',middle_name='$middle_name',last_name='$last_name',address='$address',email='$email',phone='$phone',password='$password',client='$client',offadd='$offadd' WHERE id = '$id'";
            mysqli_query($database,$sql3)or die(mysqli_error($database));
        }
        else {
            $sql3="UPDATE users SET username='$username',first_name='$first_name',middle_name='$middle_name',last_name='$last_name',address='$address',email='$email',phone='$phone',password='$password' WHERE id = '$id'";
            mysqli_query($database,$sql3)or die(mysqli_error($database));
        }

        if ($username == $temp) {
            header("location:../home.php?username=$username&request=profile-update&status=success");
        }
        else {
            echo "<script>alert('Username changed. Please re-login.');document.location='../index.php?logout=success'</script>";
        }
    }    
?>
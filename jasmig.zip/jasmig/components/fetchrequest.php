

<?php
	$txtbox = $_POST['txt'];

	foreach ($txtbox as $a => $b) {
		echo "$txtbox[$a]";
	}
?>
<?php
    session_start();
    include '../_database/database.php';


    $projid=$_REQUEST['projid'];
    $projname=$_REQUEST['projname'];
    $projmcw=$_REQUEST['projmcw'];
    $projmanager=$_REQUEST['projmanager'];

    if(isset($_REQUEST['approve'])){
        $sqla = "UPDATE requisition SET prapproved = '$projmanager' WHERE projid = '$projid' && projname = '$projname' && projmcw = '$projmcw'";
        mysqli_query($database,$sqla) or die(mysqli_error($database));

        header('location:../dashboard.php?projid='.$projid.'&projmcw='.$projmcw.'');
    }

    if(isset($_REQUEST['finish'])){

    	$sql = "UPDATE project SET projend_actual = curdate() WHERE projid = '$projid' && projname = '$projname' && projmcw = '$projmcw' && projmanager = '$projmanager'";
        mysqli_query($database,$sql) or die(mysqli_error($database));

        header('location:../home.php');
	}
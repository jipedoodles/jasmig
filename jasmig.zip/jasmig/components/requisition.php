<?php
    session_start();
    include '../_database/database.php';
    if(isset($_REQUEST['submit'])){

        $prno=$_POST['prno'];
        $projchecker=$_POST['projchecker'];
        $projdatenow=$_POST['projdatenow'];
        $prdate_need=$_POST['prdate_need'];
        $prrequestby=$_POST['prrequestby'];
        $prremarkb=$_POST['prremarkb'];
        $projid=$_POST['projid'];
        $projname=$_POST['projname'];
        $projmcw=$_POST['projmcw'];

    	$s = "INSERT INTO requisition (prno, projchecker, projdatenow, projid, projname, projmcw, prdate_need, pritem, prquantity, printended, prremarka, prrequestby, prremarkb) VALUES";

    	for($i=0;$i<$_POST['numbers'];$i++) {
            $s .="('$prno', '$projchecker', '$projdatenow', '$projid', '$projname', '$projmcw', '$prdate_need', '".$_POST['pritem'][$i]."', '".$_POST['prquantity'][$i]."','".$_POST['printended'][$i]."','".$_POST['prremarka'][$i]."', '$prrequestby', '$prremarkb'),";
    	}
    	$s = rtrim($s,",");
    	mysqli_query($database,$s) or die(mysqli_error($database));
    	$d = "DELETE FROM requisition WHERE pritem = ''";
    	mysqli_query($database,$d) or die(mysqli_error($database));

        header('location:../home.php');
    }
?>
<?php
    session_start();
    require '_database/database.php';
    $username=$_SESSION['username'];
?>
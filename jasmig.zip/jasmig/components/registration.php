<?php
    session_start();
    include '../_database/database.php';
    if(isset($_REQUEST['signup_button'])){
        $email=$_REQUEST['email'];
        $first_name=$_REQUEST['first_name'];
        $middle_name=$_REQUEST['middle_name'];
        $last_name=$_REQUEST['last_name'];
        $username=$_REQUEST['username'];
        $password=$_REQUEST['password'];
        $position=$_REQUEST['position'];
        $sql="INSERT INTO users(first_name,middle_name,last_name,username,password,position,avatar) VALUES('$first_name','$middle_name','$last_name','$username','$password','$position','default.jpg')";
        mysqli_query($database,$sql) or die('<script type="text/javascript">alert("Username already in use. Please use another.");location.replace("../index.php")</script>');
        header('location:../all-users.php');
    }
?>
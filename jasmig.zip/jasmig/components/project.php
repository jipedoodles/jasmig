<?php
    session_start();
    include '../_database/database.php';
    if(isset($_REQUEST['signup_button'])){

            $projman = $_SESSION['username'];
            $sql = "SELECT * FROM users WHERE username ='$projman'";
            $result = mysqli_query($database, $sql);
            $row = mysqli_fetch_array($result);

        ${'d' . 'e' . 'f'} = $row['first_name'] ." ". $row['middle_name'] ." ". $row['last_name'];   
        ${'a' . 'b' . 'c'} = $_POST['projmcwa'] ."-". $_POST['projmcwb'] ."-". $_POST['projmcwc'];
        $projid=$_REQUEST['projid'];
        $projname=$_REQUEST['projname'];
        $projclient=$_REQUEST['projclient'];
        $projmanager=$def;
        $projchecker=$_REQUEST['projchecker'];
        $projengineer=$_REQUEST['projengineer'];
        $projbudget=$_REQUEST['projbudget'];
        $projlocation=$_REQUEST['projlocation'];
        $projstart=$_REQUEST['projstart'];
        $projend=$_REQUEST['projend'];
        $projmcw=$abc;
        $projdimension=$_REQUEST['projdimension'];
        $sql="INSERT INTO project(projid,projname,projclient,projmanager,projchecker,projengineer,projbudget,projlocation,projstart,projend,projmcw,projdimension) VALUES ('$projid','$projname','$projclient','$projmanager','$projchecker','$projengineer','$projbudget','$projlocation','$projstart','$projend','$projmcw','$projdimension')";
        mysqli_query($database,$sql) or die(mysqli_error($database));
        $_SESSION['projname'] = $projname;
        header('location:../home.php?id=projdate_added&action=desc');
    }
?>
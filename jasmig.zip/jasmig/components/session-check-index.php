<?php
    require '_database/database.php';
    if(isset($_POST['username'])) { 
        header("location:home.php");
    }
?>
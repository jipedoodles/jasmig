<?php
    session_start();
    include '../_database/database.php';
    if(isset($_REQUEST['signup_button'])){

        $projid=$_REQUEST['projid'];
        $projname=$_REQUEST['projname'];
        $projmcw=$_REQUEST['projmcw'];
        $projdatenow=$_REQUEST['projdatenow'];
        $projweather=$_REQUEST['projweather'];
        $projchecker=$_REQUEST['projchecker'];


        $sql1 = "INSERT into logbook (projid, projname, projmcw, projdatenow, projweather, projchecker) VALUES ('$projid', '$projname', '$projmcw', '$projdatenow', '$projweather', '$projchecker')";
            mysqli_query($database,$sql1) or die(mysqli_error($database));

        

        header('location:../deliveries.php?projid='.$projid.'&projmcw='.$projmcw.'');

    }
?>
<?php
    session_start();
    include '../_database/database.php';
    if(isset($_REQUEST['signup_button'])){
    	header('Content-Description: File Transfer');
    	header('Content-Type: application/octet-stream');
    	header('Content-Disposition: attachment; filename=data.csv');
    	header('Expires: 0');
    	header('Cache-Control: must-revalidate');
    	header('Pragma: public');
    	exit;
    }
?>
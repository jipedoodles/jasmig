<?php
    header( "refresh:1;url=../index.php" ); 
    echo "<center><h3>Wrong Username or Password. Redirecting shortly!</h3></center>";
?>
<?php
    require '_database/database.php';
    if(!$_SESSION['username']){
        header("location:login.php?session=notset");
    }
?>
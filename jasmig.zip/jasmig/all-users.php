<?php include 'components/authentication.php' ?>     
<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/nav/nav.php' ?>  
 
  <div class="container">
    <div class="row clearfix">
      <div class="col-md-12 column">
        <div class="row clearfix">
<?php
    include '_database/database.php';
    $current_user = $_SESSION['username'];
    $sql = "SELECT * FROM users WHERE username != '$current_user' order by last_name ASC";
    $result = mysqli_query($database,$sql) or die(mysqli_error($database));
    while($rws = mysqli_fetch_array($result)){ 
?>
          <div class="col-md-4 col-lg-3 column">
            <div class="panel-group" id="panel-<?php echo $rws['id']; ?>">
              <div class="panel panel-default">
                <div id="panel-element-<?php echo $rws['id']; ?>" class="panel-collapse collapse in">
                  <div class="panel-body">
                    <div class="col-md12 column">
                      <center><img src="userfiles/avatars/<?php echo $rws['avatar'];?>" name="aboutme" width="100px" height="100px">
                      <h4><a href="profile.php?username=<?php echo $rws['username'];?>"><?php echo $rws['last_name'];?>, <?php echo $rws['first_name'];?></a></h4>
                      <h6><?php echo $rws['position'];?></h6>
                      </center>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
 <?php } ?>                                                         
        </div>
      </div>
    </div>
  </div>
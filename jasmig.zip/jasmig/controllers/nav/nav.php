<?php
    $current_user = $_SESSION['username'];
    $sql = "SELECT * FROM users WHERE username='$current_user'";
    $result = mysqli_query($database,$sql);
    while($row = mysqli_fetch_array($result,MYSQLI_BOTH)) {
?>

<div id="navigation" class="navbar navbar-default navbar-fixed-top">
    <div class="fluid-container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse1">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
            <a class="navbar-brand" href="http://www.jasmig.net"><img src="assets/img/logo1.png" width="20px" height="20px"></a>
            <a class="navbar-brand" href="home.php"><i class="fa fa-home"></i> Home</a>            
        </div>
        <div class="navbar-collapse collapse" id="navbar-collapse1">
            <ul class="nav navbar-nav navbar-right" style="padding-right: 15px;">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i>
                         <?php echo $row['first_name'];?> <?php echo $row['last_name'];?>
                    <strong class="caret"></strong></a>                  
                    <ul class="dropdown-menu" style="margin-right: 5px;">
                        <li>
                            <h5><center><?php echo $row['position'];?></center></h5>
                            <hr>
                        </li>
<?php
    if ($row['position'] == 'head manager') {?>
                        <li>
                            <a href="index-project.php"><i class="fa fa-edit"></i> Add Project</a>
                            <a href="all-projects.php?id=projname"><i class="fa fa-book"></i> All Projects</a>
                            <hr>
                            <a href="index-profile.php"><i class="fa fa-edit"></i> Add User</a>
                            <a href="all-users.php"><i class="fa fa-edit"></i> View All Users</a>
                            <hr>
                            <a href="edit-profile.php"><i class="fa fa-edit"></i> Edit Profile</a>
                            <a href="components/logout.php"><i class="fa fa-mail-reply"></i> Logout</a>
                        </li>
<?php    }?>
<?php
    if ($row['position'] == 'project manager') {?>
                        <li>
                            <a href="edit-profile.php"><i class="fa fa-edit"></i> Edit Profile</a>
                            <hr>
                            <a href="components/logout.php"><i class="fa fa-mail-reply"></i> Logout</a>
                        </li>
<?php    }?>
<?php
    if ($row['position'] == 'checker') {?>
                        <li>
                            <a href="edit-profile.php"><i class="fa fa-edit"></i> Edit Profile</a>
                            <hr>
                            <a href="components/logout.php"><i class="fa fa-mail-reply"></i> Logout</a>
                        </li>
<?php    }?>
<?php
    if ($row['position'] == 'purchasing officer') {?>
                        <li>
                            <a href="edit-profile.php"><i class="fa fa-edit"></i> Edit Profile</a>
                            <hr>
                            <a href="components/logout.php"><i class="fa fa-mail-reply"></i> Logout</a>
                        </li>
<?php    }?>
<?php
    if ($row['position'] == 'project engineer') {?>
                        <li>
                            <a href="edit-profile.php"><i class="fa fa-edit"></i> Edit Profile</a>
                            <hr>
                            <a href="components/logout.php"><i class="fa fa-mail-reply"></i> Logout</a>
                        </li>
<?php    }?>

<?php
    if ($row['position'] == 'client') {?>
                        <li>
                            <a href="edit-profile.php"><i class="fa fa-edit"></i> Edit Profile</a>
                            <hr>
                            <a href="components/logout.php"><i class="fa fa-mail-reply"></i> Logout</a>
                        </li>
<?php    }?>
                    </ul>
                </li>   
            </ul>
        </div>
    </div>
</div>

<?php
    }
?>
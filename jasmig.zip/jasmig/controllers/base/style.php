<?php
    if (isset($_GET['username'])) {
        $username = $_GET['username'];
    }
    $sql = "SELECT * FROM users where username='$username'";
    $result = mysqli_query($database,$sql) or die(mysqli_error()); 
    $rws = mysqli_fetch_array($result);       
?>
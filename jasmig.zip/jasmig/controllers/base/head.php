<?php include 'controllers/base/meta-tags.php' ?>

	<title>Jasmig</title>
	<link rel = "icon" type = "image/png" href = "userfiles/avatars/logo1.png">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<?php include 'controllers/base/javascript.php' ?>
<?php include 'controllers/base/css.php' ?>
<?php include 'controllers/base/font.php' ?>
<?php 
    $now = new DateTime();
    $now->setTimezone(new DateTimeZone('Asia/Manila'));
?>
<style>
	h3 {
		line-height: 1.0;
	}
    input {
        text-align: center;
        border: none;
    }
    input[type=date]::-webkit-inner-spin-button {
        -webkit-appearance: none;
        display: none;
    }
    option[value=""][disabled] {
        display: none;
    }
    #proj {
        text-align: center;
        vertical-align: middle;
    }
    select {
    	text-align-last: center;
        -webkit-appearance: none;
    }
    select:required:invalid {
        color: gray;
    }
    th,td {
        font-size: 10px;
        text-align: center;
    }
    tr:hover {
        background-color: #f5f5f5;
        cursor: pointer;
    }
    .fa-toggle-down {
        position: absolute;
        right: 20;
        top: 10;
        color: #aaa;
    }
    .form-control {
        text-align: center;
    }
    .tableFixHead {
  		overflow-y: scroll;
  		height: 180px;
	}
	.tableFixHead table {
  		border-collapse: collapse;
  		width: 100%;
	}
	.tableFixHead th {
		border: 1px solid black;
  		position: sticky;
  		top: 0;
	}
</style>

<script>
	function showpass() {
    	var x = document.getElementById("inputPassword");
    	if (x.type === "password") {
        	x.type = "text";
    	} 
    	else {
        	x.type = "password";
    	}
  	}

  	$(function(){       
    	$('*[data-href]').click(function(){
        	window.location = $(this).data('href');
        	return false;
    	});
	});

    function addDashes(f) {
        f.value = f.value.slice(0,2)+"-"+f.value.slice(2,8);
    }  
</script>
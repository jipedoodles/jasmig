<div style="padding: 0 5 5 5;"><center><h3><?php echo $row1['projid'] .': '. $row1['projname'].'<br>'.$row1['projmcw'];?></h3></center></div>
<form action="components/purchase.php" method="post">
	<div style="border: 2px solid black; border-radius: 4px; padding: 5px 5px 5px 5px; margin-left: 10px; margin-right: 10px; overflow: hidden;">
		<div class="col-md-12">
			<div class="form-group col-md-3" style="float: right; margin-top: -10px;">
                <input type="text" class="form-control" value="<?php echo $now->format('F j, Y');?>">
            </div>
			<h4>Purchase Requisitions</h4>
			<div class="table table-responsive" style="border: 1px solid;">
				<table class="table table-striped table-bordered">
					<tr>
						<th>Items/Descriptions</th>
						<th>Quantity</th>
						<th>Intended for</th>
						<th>Remarks</th>
						<th>Date Needed</th>
						<th>Requested by</th>
						<th>Approved by</th>
						<th>Remarks</th>
						<th>Date & Time taken</th>
					</tr>
				<?php  
    			while ($row3 = mysqli_fetch_array($result3)) {
        			echo 
            		'<tr>
                		<td id="proj">'.$row3["pritem"].'</td>
                		<td id="proj">'.$row3["prquantity"].'</td>
                		<td id="proj">'.$row3["printended"].'</td>
                		<td id="proj">'.$row3["prremarka"].'</td>
                		<td id="proj">'.$row3["prdate_need"].'</td>
                		<td id="proj">'.$row3["prrequestby"].'</td>
                		<td id="proj">'.$row3["prapproved"].'</td>
                		<td id="proj">'.$row3["prremarkb"].'</td>
                		<td id="proj">'.$row3["projdatetime"].'</td>
            		</tr>'
				?>
				<?php } ?>
				</table>
			</div>
		</div>
	</div>
</form>
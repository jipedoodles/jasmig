<div style="padding: 0 5 5 5;"><center><h3><?php echo $row1['projid'] .': '. $row1['projname'].'<br>'.$row1['projmcw'];?></h3></center></div>
<form action="components/requisition.php" method="post">
	<div style="border: 2px solid black; border-radius: 4px; padding: 10px 10px 0px 10px; margin-left: 10px; margin-right: 10px; overflow: hidden; ">
		<center><h4>Purchase Requisition</h4></center>
		<div class="form-group col-md-10"></div>
    	<div class="form-group col-md-2">
     		<input type="text" class="form-control" name="prno" placeholder="PR No.:" maxlength="7"  onblur="addDashes(this)" required>
    	</div>
		
		<div class="form-group col-md-4">
			<input type="text" class="form-control" name="projchecker" placeholder="Name:" value="<?php echo $row1['projchecker']?>" readonly>
		</div>
		<div class="form-group col-md-6"></div>
		<div class="form-group col-md-2">
			<input type="text" class="form-control" name="projdatenow" value="<?php echo date("Y-m-d");?>" readonly>
		</div>

		<div class="form-group col-md-10">
			<input type="text" class="form-control" name="prdeptproj" placeholder="Department/Project:" value="<?php echo $row1['projname'].'; '.$row1['projmcw']?>">
		</div>
		<div class="form-group col-md-2">
			<input type="text" class="form-control" name="prdate_need" placeholder="Date Needed:" onfocus="(this.type='date')" onblur="(this.type='text')" style="padding: 0px 10px;">
		</div>

		<div class="table table-responsive" style="border: 1px solid;">
			<table class="table table-striped table-bordered">
				<tr>
					<th>No.</th>
					<th>Items/Description</th>
					<th>Quantity</th>
					<th>Intended for</th>
					<th>Remarks</th>
				</tr>
<?php
	$numbers = 25;
	for($i=1;$i<=$numbers;$i++) {
?>
				<tr>
					<td><?php echo $i;?><input type="hidden" value="<?php echo $numbers;?>" name="numbers" /></td>
					<td><input type="text" name="pritem[]" /></td>
					<td><input type="text" name="prquantity[]" /></td>
					<td><input type="text" name="printended[]" /></td>
					<td><input type="text" name="prremarka[]" /></td>
				</tr>
<?php } ?>
			</table>
		</div>
		
		<div class="form-group col-md-6">
			<td><input type="text" name="prrequestby" class="form-control" placeholder="Requested by:"></td>
		</div>
		<div class="form-group col-md-6">
			<td><input type="text" name="prremarkb" class="form-control" placeholder="Remarks:"></td>
		</div>
		<div class="form-group col-md-12">
			<input type="hidden" value="<?php echo $row1['projid'];?>" name="projid" />
			<input type="hidden" value="<?php echo $row1['projname'];?>" name="projname" />
			<input type="hidden" value="<?php echo $row1['projmcw'];?>" name="projmcw" />
			<center>
				<button class="btn btn-primary ladda-button" type="submit"  id="SubmitButton" value="Insert" name="submit">Log</button>
			</center>
    	</div>
	</div>

</form>
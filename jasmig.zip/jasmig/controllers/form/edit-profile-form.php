<center><h2>Edit Profile</h2></center>
<form action="components/update-profile.php" method="post" enctype="multipart/form-data" id="UploadForm" style="padding: 10;">
    <div  style="font-family: FontAwesome; border: 2px solid black; border-radius: 4px; margin: 0 10 0 10;">
    <div class="col-md-4">
        <div class="form-group">
            <label>First Name</label>
            <input type="text" class="form-control" placeholder="<?php echo $rws['first_name'];?>" value="<?php echo $rws['first_name'];?>" name="first_name">
        </div>
        <div class="form-group">
            <label>Middle Name</label>
            <input type="text" class="form-control" placeholder="<?php echo $rws['middle_name'];?>" value="<?php echo $rws['middle_name'];?>" name="middle_name">
        </div>
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" class="form-control" placeholder="<?php echo $rws['last_name'];?>" value="<?php echo $rws['last_name'];?>" name="last_name">
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text" class="form-control" placeholder="<?php echo $rws['address'];?>" name="address" value="<?php echo $rws['address'];?>" required>
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group" style="position: relative;">
            <label>Username</label>
                <input type="username" class="form-control" name="username" value="<?php echo $rws['username'];?>" id="username" placeholder="<?php echo $rws['username'];?>">
                <span class="input-group-addon" id="status" style="position: absolute; right: 0; bottom: 0; height: 34px; width: 38px;"></span>
        </div>    
        <div class="form-group" style="position: relative;">
            <label>Password</label>
            <input type="password" class="form-control" name="password" value="<?php echo $rws['password'];?>" id="inputPassword" placeholder="<?php echo $rws['password'];?>">
            <button type="button" class="btn btn btn-primary ladda-button" onclick="showpass()" style="position: absolute; right: 0; bottom: 0;">&#xf070;</button>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="text" class="form-control" name="email" value="<?php echo $rws['email'];?>"" placeholder="<?php echo $rws['email'];?>">
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" class="form-control" name="phone" value="<?php echo $rws['phone'];?>"" placeholder="<?php echo $rws['phone'];?>">
        </div>
    </div>


    <div class="form-group col-md-4">
        <label>Avatar</label>
        <input type="file" name="ImageFile" id="uploadFile">
        <div class="col-md-6">
            <div class="shortpreview">
                <label>Current Avatar</label>
                <img src="userfiles/avatars/<?php echo $rws['avatar'];?>" class="img-responsive">
                <br>
            </div>
        </div>
        <div class="col-md-6">
            <div class="shortpreview" id="uploadImagePreview">
                <label>Preview Avatar</label>
                <div id="imagePreview"></div>
            </div>
        </div>
    </div>

    <?php
        if ($rws['position'] == 'client') {
            echo '
                <div class="form-group col-md-12">
                    <div class="col-md-6">
                        <label>Affiliation</label>
                        <input type="text" class="form-control" name="client" value="';echo $rws["client"].'" placeholder="';echo $rws["client"].'">
                    </div>
                    <div class="col-md-6">
                        <label>Office Address</label>
                        <input type="text" class="form-control" name="offadd" value="';echo $rws["offadd"].'" placeholder="';echo $rws["offadd"].'">
                    </div>
                </div>
                <div class="submit form-group">
                    <center>
                    <button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload">Save Your Profile</button>
                    </center>        
                </div>
                ';
        }
        else {
            echo '
                <div class="submit form-group">
                    <center>
                    <button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload">Save Your Profile</button>
                    </center>        
                </div>
                ';
        }
    ?>
</form>
<div style="padding: 0 5 5 5;"><center><h3><?php echo $a .': '. $b .'<br>'. $c;?></h3></center></div>
<form action="components/delay.php" method="post" enctype="multipart/form-data">
	<div style="border: 2px solid black; border-radius: 4px; padding: 10px 10px 0px 10px; margin-left: 10px; margin-right: 10px; overflow: hidden;">
		<div class="col-md-12">
			<div class="col-md-3 form-group" style="float: right;">
            	<input type="text" class="form-control" value="<?php echo $now->format('F j, Y');?>">
        	</div>
			<h4>Factors for Delays</h4>
			<div class="table table-responsive">
				<table class="table table-striped table-bordered">
					<tr>
						<th></th>
						<th>Start</th>
						<th>Current Date</th>
						<th>Completed?</th>
					</tr>
					<tr>
						<td>Right of Way</td>
						<td><input type="date" name="progrowstart"></td>
						<td><input type="text" name="progrowend" value="<?php echo date("Y-m-d");?>" readonly></td>
						<td><input type="checkbox" name="checkbox" value="Yes"></td>
					</tr>
					<tr>
						<td>Tree-cutting Permit</td>
						<td><input type="date" name="progtcpstart"></td>
						<td><input type="text" name="progtcpend" value="<?php echo date("Y-m-d");?>" readonly></td>
						<td><input type="checkbox" name="checkbox" value="Yes"></td>
					</tr>
					<tr>
						<td>Pipe Relocation</td>
						<td><input type="date" name="progpipestart"></td>
						<td><input type="text" name="progpipeend" value="<?php echo date("Y-m-d");?>" readonly></td>
						<td><input type="checkbox" name="checkbox" value="Yes"></td>
					</tr>
					<tr>
						<td>Pole Relocation</td>
						<td><input type="date" name="progpolestart"></td>
						<td><input type="text" name="progpoleend" value="<?php echo date("Y-m-d");?>" readonly></td>
						<td><input type="checkbox" name="checkbox" value="Yes"></td>
					</tr>
				</table>
			</div>

			<h4>Purchase Requisition</h4>
			<div class="table table-responsive">
				<table class="table table-striped table-bordered">
					<tr>
						<th>PR No.:</th>
						<th>Checker</th>
						<th>Date Needed</th>
						<th>Items/Descriptions</th>
						<th>Quantity</th>
						<th>Intended for</th>
						<th>Remarks</th>
						<th>Requested by</th>
						<th>Note?</th>
						<th>Approved</th>
						<th>Remarks</th>
					</tr>
<?php  
    	while ($row1 = mysqli_fetch_array($result)) {
        	echo 
            		'<tr>
                		<td id="proj">'.$row1["prno"].'</td>
                		<td id="proj">'.$row1["projchecker"].'</td>
                		<td id="proj">'.$row1["prdate_need"].'</td>
	                	<td id="proj">'.$row1["pritem"].'</td>
    	            	<td id="proj">'.$row1["prquantity"].'</td>
        	        	<td id="proj">'.$row1["printended"].'</td>
            	    	<td id="proj">'.$row1["prremarka"].'</td>
                		<td id="proj">'.$row1["prrequestby"].'</td>
    	            	<td id="proj"><input type="checkbox" value="Yes"></td>
        	        	<td id="proj">'.$row1["prapproved"].'</td>
        	        	<td id="proj">'.$row1["prremarkb"].'</td>
            		</tr>'
?>
<?php } ?>
			</table>
		</div>
	</div>
</form>
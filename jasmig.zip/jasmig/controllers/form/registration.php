<style>
    input, select {
        text-align-last: left;
    }
    .input-group-addon {
        width: 20%;
    }
</style>

<center><h2>New User</h2></center>
<form action="components/registration.php" method="post" autocomplete="off" style="font-family: FontAwesome; border: 2px solid black; border-radius: 4px;padding: 10 10 10 10; margin: 0 auto; width: 225px;">
    <div class="form-group">
        <input type="text" class="form-control input-lg" placeholder="First Name" name="first_name" required autofocus="autofocus">
    </div>
    <div class="form-group">
        <input type="text" class="form-control input-lg" placeholder="Middle Name" name="middle_name" required>
    </div>
    <div class="form-group">
        <input type="text" class="form-control input-lg" placeholder="Last Name" name="last_name" required>
    </div>
    <div class="form-group" style="position: relative;">
        <select class="form-control" name="position" id="position" style="padding: 0 5px;" required>
            <option value="" disabled selected>- Select position -</option>
            <option <?php if (isset($rws['position']) && $rws['position']=="checker") echo "selected";?>>checker</option>
            <option <?php if (isset($rws['position']) && $rws['position']=="client") echo "selected";?>>client</option>
            <option <?php if (isset($rws['position']) && $rws['position']=="project engineer") echo "selected";?>>project engineer</option>
            <option <?php if (isset($rws['position']) && $rws['position']=="purchasing officer") echo "selected";?>>purchasing officer</option>
        </select>
        <i class="fa fa-toggle-down" style="position: absolute; right: 10px; top: 10px; color: #aaa;"></i>
    </div>
    <div class="form-group">
        <div class="input-group">
            <input type="username" class="form-control input-lg" placeholder="Username" name="username" id="username" required> 
            <span class="input-group-addon" id="status"></span>
        </div>
    </div>
    <div class="form-group" style="position: relative;">
        <input type="password" class="form-control" id="inputPassword" name="password" placeholder="Password">
        <button type="button" class="btn btn btn-primary ladda-button" onclick="showpass()" style="position: absolute; right: 0; top: 0;">&#xf070;</button>
    </div>
    <div>
        <center><button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="signup_button"/>Register</button></center>
    </div>
</form>
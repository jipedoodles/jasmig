<div style="padding: 0 5 5 5;"><center><h3><?php echo $row1['projid'] .': '. $row1['projname'].'<br>'.$row1['projmcw'];?></h3></center></div>
<div style="border: 2px solid black; border-radius: 4px; padding: 10px 10px 0px 10px; margin: 10px; overflow: hidden; ">
	<form action="components/deliveries.php" method="post">
		<center><h4>Deliveries Logbook</h4></center>
		<div class="table table-responsive" style="border: 1px solid;">
			<table class="table table-striped table-bordered">
				<tr>
					<th>No.</th>
					<th>Items/Description</th>
					<th>Quantity</th>
					<th>Intended for</th>
					<th>Remarks</th>
				</tr>
<?php
	$numbers = 25;
	for($i=1;$i<=$numbers;$i++) {
?>
				<tr>
					<td><?php echo $i;?><input type="hidden" value="<?php echo $numbers;?>" name="numbers" /></td>
					<td><input type="text" name="dlitem[]" /></td>
					<td><input type="text" name="dlquantity[]" /></td>
					<td><input type="text" name="dlintended[]" /></td>
					<td><input type="text" name="dlremarka[]" /></td>
				</tr>
<?php } ?>
			</table>
		</div>
		<div class="form-group">
				<input type="hidden" value="<?php echo $row1['projid'];?>" name="projid" />
				<input type="hidden" value="<?php echo $row1['projname'];?>" name="projname" />
				<input type="hidden" value="<?php echo $row1['projmcw'];?>" name="projmcw" />
			<center>
				<button class="btn btn-primary ladda-button" type="submit"  id="SubmitButton" value="Insert" name="submit">Log</button>
			</center>
		</div>
	</form>
</div>
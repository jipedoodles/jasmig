<style>
    tr:hover {
        background-color: white;
        cursor: default;
    }
</style>
<div style="padding: 0 5 5 5;"><center><h3><?php echo $row1['projid'] .': '. $row1['projname'].'<br>'.$row1['projmcw'];?></h3></center></div>
<form action="components/dashboard.php" method="post">
	<div style="border: 2px solid black; border-radius: 4px; padding: 5px 5px 5px 5px; margin-left: 10px; margin-right: 10px; overflow: hidden;">
        <div class="col-md-12">
            <br>
            <div class="form-group col-md-3" style="float: right;">
                <input type="text" class="form-control" value="<?php echo $now->format('F j, Y');?>">
            </div>
            <div class="form-group col-md-2" style="float: right;">
                <input type="text" class="form-control" value="<?php echo "Days left: ".$diff->format("%a");?>">
            </div>
			<h4>Project Details</h4>
			<div class="table table-responsive" style="border: 1px solid;">
				<table class="table table-striped table-bordered">
					<tr>
                		<th id="proj">Date Added</th>
                		<th id="proj">Project ID</th>
                		<th id="proj">Project Name</th>
                		<th id="proj">Major Categories of Work</th>
                		<th id="proj">Client</th>
                		<th id="proj">Checker</th>
                		<th id="proj">Site Engineer</th>
                		<th id="proj">Project Budget</th>
                		<th id="proj">Site Location</th>
                		<th id="proj">Dimension</th>
                		<th id="proj">Started</th>
                		<th id="proj">Target End</th>
                		<th id="proj"></th>
            		</tr>
            		<tr>
                		<td id="proj"><?php echo $row1['projdate_added'];?></td>
                		<td id="proj"><?php echo $row1['projid'];?></td>
                		<td id="proj"><?php echo $row1['projname'];?></td>
                		<td id="proj"><?php echo $row1['projmcw'];?></td>
                		<td id="proj"><?php echo $row1['projclient'];?></td>
                		<td id="proj"><?php echo $row1['projchecker'];?></td>
                		<td id="proj"><?php echo $row1['projengineer'];?></td>
                		<td id="proj"><?php echo 'Php ', number_format($row1["projbudget"],2);?></td>
                		<td id="proj"><?php echo $row1['projlocation'];?></td>
                		<td id="proj"><?php echo $row1['projdimension'];?></td>
                		<td id="proj"><?php echo $row1['projstart'];?></td>
                		<td id="proj"><?php echo $row1['projend'];?></td>
                		<td id="proj"><button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="finish"/>End</button></td>
            		</tr>
				</table>
			</div>
		</div>

        <div class="col-md-12">
            <h4>Progress</h4>
            <div class="table table-responsive tableFixHead" style="border: 1px solid;">
                <table class="table table-striped table-bordered">
                    <tr>
                        <th id="proj"></th>
                    </tr>
                    <tr>
                        <td id="proj"></td>
                    </tr>
                </table>
            </div>
        </div>

		<div class="col-md-3">
            <div class="form-group col-md-5" style="float: right; margin-top: 5px;">
                <input type="text" class="form-control" value="<?php echo $rain;?>" readonly>
            </div>
			<h4>Weather Chart</h4>
			<div class="table table-responsive tableFixHead" style="border: 1px solid;">
				<table class="table table-striped table-bordered">
					<tr>
						<th>Weather</th>
						<th>Date & Time taken</th>
					</tr>
				<?php  
    			while ($row2 = mysqli_fetch_array($result2)) {
        		echo 
            		'<tr>
                		<td id="proj">'.$row2["projweather"].'</td>
                		<td id="proj">'.$row2["projdatetime"].'</td>
            		</tr>'
				?>
				<?php } ?>
				</table>
			</div>
		</div>
		<div class="col-md-9">
            <div class="form-group col-md-2" style="float: right; margin-top: 5px;">
                <button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="approve"/>Approve</button>
            </div>
			<h4>Purchase Requisitions</h4>
			<div class="table table-responsive tableFixHead" style="border: 1px solid;">
				<table class="table table-striped table-bordered">
					<tr>
                        <th>PR no.</th>
						<th>Items/Descriptions</th>
						<th>Quantity</th>
						<th>Intended for</th>
						<th>Remarks</th>
						<th>Date Needed</th>
						<th>Requested by</th>
						<th>Remarks</th>
						<th>Date & Time taken</th>
					</tr>
				<?php  
    			while ($row3 = mysqli_fetch_array($result3)) {
        			echo 
            		'<tr>
                        <td id="proj">'.$row3["prno"].'</td>
                		<td id="proj">'.$row3["pritem"].'</td>
                		<td id="proj">'.$row3["prquantity"].'</td>
                		<td id="proj">'.$row3["printended"].'</td>
                		<td id="proj">'.$row3["prremarka"].'</td>
                		<td id="proj">'.$row3["prdate_need"].'</td>
                		<td id="proj">'.$row3["prrequestby"].'</td>
                		<td id="proj">'.$row3["prremarkb"].'</td>
                		<td id="proj">'.$row3["projdatetime"].'</td>
            		</tr>'
				?>
				<?php } ?>
				</table>
			</div>
		</div>

        <div class="col-md-4">
            <h4>Factors for Delays</h4>
            <div class="table table-responsive" style="border: 1px solid;">
               <table class="table table-striped table-bordered">
                    <tr>
                        <th width="90px"></th>
                        <th>Start</th>
                        <th>End</th>
                    </tr>
                    <tr>
                        <td id="proj">Right of Way</td>
                        <td id="proj"><?php echo $row4['progrowstart'];?></td>
                        <td id="proj"><?php echo $row4['progrowend'];?></td>
                    </tr>
                    <tr>
                        <td id="proj">Tree-cutting Permit</td>
                        <td id="proj"><?php echo $row4['progtcpstart'];?></td>
                        <td id="proj"><?php echo $row4['progtcpend'];?></td>
                    </tr>
                    <tr>
                        <td id="proj">Pipe Relocation</td>
                        <td id="proj"><?php echo $row4['progpipestart'];?></td>
                        <td id="proj"><?php echo $row4['progpipeend'];?></td>
                    </tr>
                    <tr>
                        <td id="proj">Pole Relocation</td>
                        <td id="proj"><?php echo $row4['progpolestart'];?></td>
                        <td id="proj"><?php echo $row4['progpoleend'];?></td>
                    </tr>
               </table>
            </div>
        </div>
        <div class="col-md-8">
            <h4>Deliveries Logbook</h4>
            <div class="table table-responsive tableFixHead" style="border: 1px solid;">
                <table class="table table-striped table-bordered">
                    <tr>
                        <th>Items/Descriptions</th>
                        <th>Quantity</th>
                        <th>Intended for</th>
                        <th>Remarks</th>
                        <th>Date & Time taken</th>
                    </tr>
                <?php  
                    while ($row5 = mysqli_fetch_array($result5)) {
                    echo 
                    '<tr>
                        <td id="proj">'.$row5["dlitem"].'</td>
                        <td id="proj">'.$row5["dlquantity"].'</td>
                        <td id="proj">'.$row5["dlintended"].'</td>
                        <td id="proj">'.$row5["dlremarka"].'</td>
                        <td id="proj">'.$row5["dldatetaken"].'</td>
                    </tr>'
                ?>
                <?php } ?>
                </table>
            </div>
        </div>
    </div>
    <input type="text" id="projid" name="projid" value="<?php echo $row1['projid'];?>" hidden>
    <input type="text" id="projname" name="projname" value="<?php echo $row1['projname'];?>" hidden>
    <input type="text" id="projmcw" name="projmcw" value="<?php echo $row1['projmcw'];?>" hidden>
    <input type="text" id="projmanager" name="projmanager" value="<?php echo $row1['projmanager'];?>" hidden>
    <input type="text" id="prno" name="prno" value="<?php echo $row3['pritem'];?>" >
</form>
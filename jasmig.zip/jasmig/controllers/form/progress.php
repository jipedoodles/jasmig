<style>
    tr:hover {
        background-color: white;
        cursor: default;
    }
</style>
<div style="padding: 0 5 5 5;"><center><h3><?php echo $a .': '. $b .'<br>'. $c;?></h3></center></div>
<form action="components/progress.php" method="post" enctype="multipart/form-data">
    <div style="border: 2px solid black; border-radius: 4px; padding: 5px 5px 5px 5px; margin-left: 10px; margin-right: 10px; overflow: hidden;">
        <div class="col-md-12">
            <br>
            <div class="form-group col-md-3" style="float: right;">
                <input type="text" class="form-control" value="<?php echo $now->format('F j, Y');?>">
            </div>
            <h4>Factors for Delays</h4>
            <div class="table table-responsive" style="border: 1px solid;">
                <table class="table table-striped table-bordered">
                    <tr>
                        <th id="proj"></th>
                        <th id="proj">Start Date</th>
                        <th id="proj">End Date</th>
                        <th id="proj"></th>
                    </tr>
                    <tr>
                        <td id="proj">Right of Way</td>
                        <td id="proj"><input type="date" name="progrowstart"></td>
                        <td id="proj"><input type="text" name="progrowend" value="" readonly></td>
                        <td id="proj"><button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="finish"/>End</button></td>
                    </tr>
                    <tr>
                        <td>Tree-cutting Permit</td>
                        <td id="proj"><input type="date" name="progtcpstart"></td>
                        <td id="proj"><input type="text" name="progtcpend" value="" readonly></td>
                        <td id="proj"><button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="finish"/>End</button></td>
                    </tr>
                    <tr>
                        <td id="proj">Pipe Relocation</td>
                        <td id="proj"><input type="date" name="progpipestart"></td>
                        <td id="proj"><input type="text" name="progpipeend" value="" readonly></td>
                        <td id="proj"><button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="finish"/>End</button></td>
                    </tr>
                    <tr>
                        <td id="proj">Pole Relocation</td>
                        <td id="proj"><input type="date" name="progpolestart"></td>
                        <td id="proj"><input type="text" name="progpoleend" value="" readonly></td>
                        <td id="proj"><button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="finish"/>End</button></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="col-md-12">

        </div>
    </div>
</form>
<style>
    tr:hover {
        background-color: white;
        cursor: default;
    }
</style>
<div style="padding: 0 5 5 5;"><center><h3><?php echo $row1['projid'] .': '. $row1['projname'].'<br>'.$row1['projmcw'];?></h3></center></div>
<form action="components/client.php" method="post">
	<div style="border: 2px solid black; border-radius: 4px; padding: 5px 5px 5px 5px; margin-left: 10px; margin-right: 10px; overflow: hidden;">
        <div class="col-md-12">
            <div class="form-group col-md-3" style="float: right; margin-top: -10px;">
                <input type="text" class="form-control" value="<?php echo $now->format('F j, Y');?>">
            </div>
            <div class="form-group col-md-2" style="float: right; margin-top: -10px;">
                <input type="text" class="form-control" value="<?php echo "Days left: ".$diff->format("%a");?>">
            </div>
			<h4>Project Details</h4>
			<div class="table table-responsive" style="border: 1px solid;">
				<table class="table table-striped table-bordered">
					<tr>
                		<th id="proj">Project ID</th>
                		<th id="proj">Project Name</th>
                		<th id="proj">Major Categories of Work</th>
                		<th id="proj">Client</th>
                		<th id="proj">Checker</th>
                		<th id="proj">Site Engineer</th>
                		<th id="proj">Project Budget</th>
                		<th id="proj">Site Location</th>
                		<th id="proj">Dimension</th>
                		<th id="proj">Started</th>
                		<th id="proj">Target End</th>
            		</tr>
            		<tr>
                        <td id="proj"><?php echo $row1['projid'];?></td>
                		<td id="proj"><?php echo $row1['projname'];?></td>
                		<td id="proj"><?php echo $row1['projmcw'];?></td>
                		<td id="proj"><?php echo $row1['projclient'];?></td>
                		<td id="proj"><?php echo $row1['projchecker'];?></td>
                		<td id="proj"><?php echo $row1['projengineer'];?></td>
                		<td id="proj"><?php echo 'Php ', number_format($row1["projbudget"],2);?></td>
                		<td id="proj"><?php echo $row1['projlocation'];?></td>
                		<td id="proj"><?php echo $row1['projdimension'];?></td>
                		<td id="proj"><?php echo $row1['projstart'];?></td>
                		<td id="proj"><?php echo $row1['projend'];?></td>
            		</tr>
				</table>
			</div>
		</div>

        <div class="col-md-12">
            <h4>Progress</h4>
            <div class="table table-responsive tableFixHead" style="border: 1px solid;">
                <table class="table table-striped table-bordered">
                    <tr>
                        <th id="proj"></th>
                    </tr>
                    <tr>
                        <td id="proj"></td>
                    </tr>
                </table>
            </div>
        </div>

		<div class="col-md-6">
			<h4>Weather Chart</h4>
			<div class="table table-responsive tableFixHead" style="border: 1px solid; height: 192px;">
				<table class="table table-striped table-bordered">
					<tr>
						<th>Weather</th>
						<th>Date & Time taken</th>
					</tr>
				<?php  
    			while ($row2 = mysqli_fetch_array($result2)) {
        		echo 
            		'<tr>
                		<td id="proj">'.$row2["projweather"].'</td>
                		<td id="proj">'.$row2["projdatetime"].'</td>
            		</tr>'
				?>
				<?php } ?>
				</table>
			</div>
		</div>
		
        <div class="col-md-6">
            <h4>Factors for Delays</h4>
            <div class="table table-responsive" style="border: 1px solid; margin-bottom: 0px;">
               <table class="table table-striped table-bordered">
                    <tr>
                        <th width="90px"></th>
                        <th>Start</th>
                        <th>End</th>
                    </tr>
                    <tr>
                        <td id="proj">Right of Way</td>
                        <td id="proj"><?php echo $row4['progrowstart'];?></td>
                        <td id="proj"><?php echo $row4['progrowend'];?></td>
                    </tr>
                    <tr>
                        <td id="proj">Tree-cutting Permit</td>
                        <td id="proj"><?php echo $row4['progtcpstart'];?></td>
                        <td id="proj"><?php echo $row4['progtcpend'];?></td>
                    </tr>
                    <tr>
                        <td id="proj">Pipe Relocation</td>
                        <td id="proj"><?php echo $row4['progpipestart'];?></td>
                        <td id="proj"><?php echo $row4['progpipeend'];?></td>
                    </tr>
                    <tr>
                        <td id="proj">Pole Relocation</td>
                        <td id="proj"><?php echo $row4['progpolestart'];?></td>
                        <td id="proj"><?php echo $row4['progpoleend'];?></td>
                    </tr>
               </table>
            </div>
        </div></form>
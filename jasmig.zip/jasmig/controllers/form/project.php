<center><h2>New Project</h2></center>
<form action="components/project.php" method="post" autocomplete="off" style="font-family: FontAwesome; border: 2px solid black; border-radius: 4px;padding: 10 0 10 0; margin: 10;">
    <div class="form-group col-md-2">
        <input type="text" class="form-control input-lg" placeholder="Contract ID" name="projid" oninput="this.value = this.value.toUpperCase()" maxlength="8" required>
    </div>
    <div class="form-group col-md-10">
        <input type="text" class="form-control input-lg" placeholder="Name of Contract" name="projname" oninput="this.value = this.value.toUpperCase()" required>
    </div>
    <div class="form-group col-md-4">
        <input type="text" class="form-control input-lg" placeholder="Location" name="projlocation" required>
    </div>
    <div class="form-group col-md-4">
        <input type="text" class="form-control input-lg" placeholder="Owner" name="projclient" list="client" style="padding: 0 15px;" required>
        <datalist id="client">
            <option value="DPWH-Batangas 1st District Engg. Office">
            <option value="DPWH-Batangas 2nd District Engg. Office">
            <option value="DPWH-Batangas 3rd District Engg. Office">
            <option value="DPWH-Batangas 4th District Engg. Office">
            <option value="DPWH-Region IV-A">
        </datalist>
    </div>
    <div class="form-group col-md-4">
        <div class="input-group">
            <span class="input-group-addon">Php</span>
            <input type="text" class="form-control input-lg" placeholder="Project Budget" name="projbudget" required>
        </div>
    </div>

    <div class="form-group col-md-12">
        <label>Major Categories of Work:</label>
        <div>
            <div class="form-group col-md-3">
                <ul style="list-style-type:none; border: 1px solid black; border-top: none; border-bottom: none;">
                    <li><input type="radio" name="projmcwa" value="Bridges"> Bridges</li>
                    <li><input type="radio" name="projmcwa" value="Buildings"> Buildings</li>
                    <li><input type="radio" name="projmcwa" value="Flood Control"> Flood Control</li>
                    <li><input type="radio" name="projmcwa" value="Roads"> Roads</li>
                    <li><input type="radio" name="projmcwa" value=""> Road Control</li>
                </ul>
            </div>
            <div class="form-group col-md-3">
                <ul style="list-style-type:none; border: 1px solid black; border-top: none; border-bottom: none;">
                    <li><input type="radio" name="projmcwb" value="Construction"> Construction</li>
                    <li><input type="radio" name="projmcwb" value="Hydraulics"> Hydraulics</li>
                    <li><input type="radio" name="projmcwb" value="Industrial Plant"> Industrial Plant</li>
                    <li><input type="radio" name="projmcwb" value="New Construction"> New Construction</li>
                    <li><input type="radio" name="projmcwb" value="Rehabilitation"> Rehabilitation</li>
                </ul>
            </div>
            <div class="form-group col-md-3">
                <ul style="list-style-type:none; border: 1px solid black; border-top: none; border-bottom: none; border-right: none;">
                    <li><input type="radio" name="projmcwc" value="Concrete"> Concrete</li>
                    <li><input type="radio" name="projmcwc" value="Drainage"> Drainage</li>
                    <li><input type="radio" name="projmcwc" value="Low Rise"> Low Rise</li>
                    <li><input type="radio" name="projmcwc" value="PCCP"> PCCP</li>
                    <li><input type="radio" name="projmcwc" value="Steel"> Steel</li>
                </ul>
            </div>
            <div class="form-group col-md-3">
                <ul style="list-style-type:none; border: 1px solid black; border-top: none; border-bottom: none; border-left: none;">
                    <li><input type="radio" name="projmcwc" value="Retrofitting"> Retrofitting</li>
                    <li><input type="radio" name="projmcwc" value="River Control"> River Control</li>
                    <li><input type="radio" name="projmcwc" value="Water Supply"> Water Supply</li>
                    <li><input type="radio" name="projmcwc" value="With Bored Piles"> With Bored Piles</li>
                    <li><input type="radio" name="projmcwc" value=""> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="form-group col-md-4">
        <input type="text" class="form-control" name="projdimension" placeholder="Dimensions" name="projdimension" required>
    </div>
    <div class="form-group col-md-4">
        <input type="text" class="form-control" name="projstart" placeholder="Start Date" onfocus="(this.type='date')" onblur="(this.type='text')" id="date" required style="padding: 0px 10px;">
    </div>
    <div class="form-group col-md-4">
        <input type="text" class="form-control" name="projend" placeholder="Target Completion Date" onfocus="(this.type='date')" onblur="(this.type='text')" id="date" required style="padding: 0px 10px;">
    </div>
        <?php
            $projman = $_SESSION['username'];
            $sql = "SELECT * FROM users WHERE username ='$projman'";
            $result = mysqli_query($database, $sql);
            $row = mysqli_fetch_array($result);
        ?>            
        <div class="form-group col-md-4">
            <input type="text" class="form-control input-lg" placeholder="Project Manager" name="projmanager" value="<?php echo $row['first_name'].' '.$row['middle_name'].' '.$row['last_name'];?>" readonly>
        </div>
        <div class="form-group col-md-4" style="position: relative;">
            <select name="projchecker" id="projchecker" class="form-control" style="padding: 0 15px;" required>
                <option value="" disabled selected>- Select one checker -</option>
                    <?php
                        $sqli = 'SELECT first_name, middle_name, last_name FROM users WHERE position = "checker" ';
                        $result = mysqli_query($database, $sqli);
                        while ($row = mysqli_fetch_array($result)) {
                            echo '<option>'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</option>';
                        }
                    ?>
                </select>
                <i class="fa fa-toggle-down"></i>
            </div>
            <div class="form-group col-md-4" style="position: relative;">
                <select name="projengineer" id="projengineer" class="form-control" style="padding: 0 15px;" required>
                    <option value="" disabled selected>- Select one site engineer -</option>
                    <?php
                        $sqli = 'SELECT first_name, middle_name, last_name FROM users WHERE position = "project engineer" ';
                        $result = mysqli_query($database, $sqli);
                        while ($row = mysqli_fetch_array($result)) {
                            echo '<option>'.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</option>';
                        }
                    ?>
                </select>
                <i class="fa fa-toggle-down"></i>
            </div>
            <div>
                <center>
                    <button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="signup_button"/>Enter</button>
                </center>
            </div>
        </div>
</form>
<div style="padding: 0 5 5 5;"><center><h3><?php echo $row1['projid'] .': '. $row1['projname'].'<br>'.$row1['projmcw'];?></h3></center></div>
<div style="border: 2px solid black; border-radius: 4px; padding: 10px 10px 0px 10px; margin-left: 10px; margin-right: 10px; overflow: hidden; ">
<form action="components/logbook.php" method="post">
	<center><h4>Weather Chart</h4></center>
	<div class="form-group col-md-2">
		<input type="text" class="form-control" name="projid" value="<?php echo $row1['projid'];?>" readonly> 
	</div>
	<div class="form-group col-md-10">
		<input type="text" class="form-control" name="projname" value="<?php echo $row1['projname'];?>" readonly> 
	</div>

	<div class="form-group col-md-4">
		<input type="text" class="form-control" name="projmcw" value="<?php echo $row1['projmcw'];?>" readonly> 	
	</div>
	<div class="form-group col-md-2">
		<input type="text" class="form-control" name="projdatenow" value="<?php echo date("Y-m-d");?>" readonly>
	</div>
	<div class="form-group col-md-3">
		<select class="form-control" name="projweather" style="padding: 0 15;" required>
			<option value="" disabled selected>- Select weather -</option>
			<option>cloudy</option>
			<option>overcast</option>
			<option>sunny</option>
			<option>rainy</option>
		</select>
		<i class="fa fa-toggle-down"></i>
	</div>
	<div class="form-group col-md-3">
		<input type="text" class="form-control" name="projchecker" value="<?php echo $row1['projchecker'];?>" readonly>
	</div>
	<div>
		<center>
			<button class="btn btn-primary ladda-button" data-style="zoom-in" type="submit"  id="SubmitButton" value="Upload" name="signup_button">Log</button>
		</center>
	</div>
</form>

<?php require '_database/database.php' ?>
<?php include 'components/authentication.php' ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/nav/nav.php' ?> 
    <div class="container">
	   <div class="no-gutter row"> 
           <div class="col-md-12">
               <div class="panel panel-default" id="sidebar">
                   <div class="panel-body">                
<?php       
    $projname = $_SESSION['projname'];   
    $sql = "SELECT * FROM project where projname ='$projname'";
    $result = mysqli_query($database,$sql) or die(mysqli_error($database)); 
    $rws = mysqli_fetch_array($result);
?>             
<?php include 'controllers/form/edit-project-form.php' ?>
                   </div>
               </div>
           </div>
        </div>
    </div>
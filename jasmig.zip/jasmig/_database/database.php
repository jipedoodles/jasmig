<?php
    $hostname = "localhost";
    $user = "root";
    $password = "";
    $database = "jasmig";
    $database=mysqli_connect($hostname,$user,$password,$database);
?>
<style>
.table-wrapper
{
    border: 1px solid red;
    width: 100px;
    height: 50px;
    overflow: auto;
}

table
{
    border: 1px solid black;
    margin-right: 20px;
}

td
{
    width: 20px;
    height: 20px;
    background-color: #ccc;
}    
</style>
<div class="table-wrapper">
    <table>
        <tr>
            <td>A</td>
            <td>B</td>
            <td>C</td>
            <td>D</td>
        </tr>
        <tr>
            <td>A</td>
            <td>B</td>
            <td>C</td>
            <td>D</td>
        </tr>
        <tr>
            <td>A</td>
            <td>B</td>
            <td>C</td>
            <td>D</td>
        </tr>
        <tr>
            <td>A</td>
            <td>B</td>
            <td>C</td>
            <td>D</td>
        </tr>
    </table>      
</div>
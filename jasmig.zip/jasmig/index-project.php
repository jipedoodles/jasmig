<?php include 'components/authentication.php' ?>
<?php include 'components/session-check.php' ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/nav/nav.php' ?>
<?php include '_database/database.php' ?>

<?php
	$sql = "SELECT * FROM users WHERE position = 'head manager'";
    $result = mysqli_query($database, $sql);
    $row = mysqli_fetch_array($result);
?>
<?php include 'controllers/form/project.php' ?>

<?php
    $result = mysqli_query($database, $sql);
    $row = mysqli_fetch_array($result);
    ${'a' . 'b' . 'c'} = $row['first_name'] ." ". $row['middle_name'] ." ". $row['last_name'];
?>

<div class="col-md-12">
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <tr>
                <th id="proj">Project ID</th>
                <th id="proj">Project Name</th>
                <th id="proj">Major Categories of Work</th>
                <th id="proj">Client</th>
                <th id="proj">Checker</th>
                <th id="proj">Site Engineer</th>
                <th id="proj">Site Location</th>
                <th id="proj">Started</th>
                <th id="proj">Target End</th>
            </tr>
<?php
    include '_database/database.php';
    $sql = "SELECT * FROM project WHERE projmanager = '$abc' && projend_actual = '0000-00-00' ORDER BY projid";
    $result = mysqli_query($database,$sql) or die(mysqli_error($database));
    while($rws = mysqli_fetch_array($result)){
?>
<?php  
        echo 
            '<tr data-href="dashboard.php?projid='.$rws["projid"].'&projmcw='.$rws["projmcw"].'">
                <td id="proj">'.$rws["projid"].'</td>
                <td id="proj">'.$rws["projname"].'</td>
                <td id="proj">'.$rws["projmcw"].'</td>
                <td id="proj">'.$rws["projclient"].'</td>
                <td id="proj">'.$rws["projchecker"].'</td>
                <td id="proj">'.$rws["projengineer"].'</td>
                <td id="proj">'.$rws["projlocation"].'</td>
                <td id="proj">'.$rws["projstart"].'</td>
                <td id="proj">'.$rws["projend"].'</td>
            </tr>'
?>
<?php } ?>
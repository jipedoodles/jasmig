-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2018 at 09:13 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jasmig`
--

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

CREATE TABLE `deliveries` (
  `projid` varchar(8) NOT NULL,
  `projname` varchar(500) NOT NULL,
  `projmcw` varchar(500) NOT NULL,
  `dlitem` varchar(500) NOT NULL,
  `dlquantity` varchar(500) NOT NULL,
  `dlintended` varchar(500) NOT NULL,
  `dlremarka` varchar(500) NOT NULL,
  `dldatetaken` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`projid`, `projname`, `projmcw`, `dlitem`, `dlquantity`, `dlintended`, `dlremarka`, `dldatetaken`) VALUES
('00000000', 'TEST.1', 'Bridges-Construction-Concrete', 'nails', '10 kilos', 'hahaha', 'hahaha', '2018-11-10 16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `logbook`
--

CREATE TABLE `logbook` (
  `projid` varchar(8) NOT NULL,
  `projname` varchar(500) NOT NULL,
  `projmcw` varchar(500) NOT NULL,
  `projdatenow` date NOT NULL,
  `projweather` varchar(255) NOT NULL,
  `projchecker` varchar(500) NOT NULL,
  `projdatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logbook`
--

INSERT INTO `logbook` (`projid`, `projname`, `projmcw`, `projdatenow`, `projweather`, `projchecker`, `projdatetime`) VALUES
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-07', 'cloudy', 'Jimuel Paulite Chavez', '2018-11-07 13:56:40'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-07', 'cloudy', 'Jimuel Paulite Chavez', '2018-11-07 13:57:39'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-07', 'overcast', 'Jimuel Paulite Chavez', '2018-11-07 14:03:36'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-07', 'rainy', 'Jimuel Paulite Chavez', '2018-11-07 14:07:31'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', '', 'Jimuel Paulite Chavez', '2018-11-11 07:08:06'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'overcast', 'Jimuel Paulite Chavez', '2018-11-11 07:08:23'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'overcast', 'Jimuel Paulite Chavez', '2018-11-11 07:09:57'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'cloudy', 'Jimuel Paulite Chavez', '2018-11-11 07:13:20'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'cloudy', 'Jimuel Paulite Chavez', '2018-11-11 07:17:46'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'overcast', 'Jimuel Paulite Chavez', '2018-11-11 07:19:18'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'cloudy', 'Jimuel Paulite Chavez', '0000-00-00 00:00:00'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'overcast', 'Jimuel Paulite Chavez', '2018-11-11 08:58:41'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'cloudy', 'Jimuel Paulite Chavez', '2018-11-11 10:14:30'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'cloudy', 'Jimuel Paulite Chavez', '2018-11-11 10:17:47'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'overcast', 'Jimuel Paulite Chavez', '2018-11-11 10:18:40'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'rainy', 'Jimuel Paulite Chavez', '2018-11-11 10:19:32'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'rainy', 'Jimuel Paulite Chavez', '2018-11-11 10:20:14'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '2018-11-11', 'rainy', 'Jimuel Paulite Chavez', '2018-11-11 10:30:10'),
('00000000', 'TEST.1', 'Bridges-Construction-Concrete', '2018-11-11', 'cloudy', 'Jimuel Paulite Chavez', '2018-11-11 14:06:48');

-- --------------------------------------------------------

--
-- Table structure for table `mcw`
--

CREATE TABLE `mcw` (
  `id` int(8) NOT NULL,
  `mcwa` varchar(50) NOT NULL,
  `mcwb` varchar(50) NOT NULL,
  `mcwc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mcw`
--

INSERT INTO `mcw` (`id`, `mcwa`, `mcwb`, `mcwc`) VALUES
(1, 'Buildings', 'Industrial Plant', 'LOW rise'),
(2, 'Flood Control', 'Hydraulics', 'Drainage'),
(3, 'Roads', 'New Construction', 'PCCP'),
(4, 'Buildings', 'Industrial Plant', 'LOW Rise'),
(5, 'Roads', 'Rehabilitation', 'PCCP'),
(6, 'Flood Control', 'Hydraulics', 'Drainage'),
(7, 'Roads', 'New Construction', 'PCCP'),
(8, 'Roads', 'New Construction', 'PCCP'),
(9, 'Bridges', 'Construction', 'With Bored Piles'),
(10, 'Flood Control', 'Hydraulics', 'River Control'),
(11, 'Roads', 'Rehabilitation', 'PCCP'),
(12, 'Buildings', 'Industrial Plant', 'LOW Rise'),
(13, 'Bridges', 'Construction', 'Concrete'),
(14, 'Flood Control', 'Hydraulics', 'Drainage'),
(15, 'Roads', 'Rehabilitation', 'PCCP'),
(16, 'Roads', 'New Construction', 'PCCP'),
(17, 'Buildings', 'Industrial Plant', 'LOW Rise'),
(18, 'Bridges', 'Rehabilitation', 'Retrofitting'),
(19, 'Roads', 'Rehabilitation', 'PCCP'),
(20, 'Roads', 'Rehabilitation', 'PCCP'),
(21, 'Flood Control', 'Hydraulics', 'Drainage'),
(22, 'Roads', 'New Construction', 'PCCP'),
(23, 'Buildings', 'Industrial Plant', 'LOW Rise'),
(24, 'Roads', 'New Construction', 'PCCP'),
(25, 'Flood Control', 'Hydraulics', 'Water Supply'),
(26, 'Roads', 'New Construction', 'PCCP'),
(27, 'Flood Control', 'Hydraulics', 'Drainage'),
(28, 'Roads', 'New Construction', 'PCCP'),
(29, 'Bridges', 'Rehabilitation', 'Concrete'),
(30, 'Flood Control', 'Hydraulics', 'Drainage'),
(31, 'Roads', 'Rehabilitation', 'PCCP'),
(32, 'Flood Control', 'Hydraulics', 'Drainage'),
(33, 'Roads', 'Rehabilitation', 'PCCP'),
(34, 'Flood Control', 'Hydraulics', 'Drainage'),
(35, 'Roads', 'New Construction', 'PCCP'),
(36, 'Bridges', 'Construction', 'Steel'),
(37, 'Roads', 'New Construction', 'PCCP'),
(38, 'Roads', 'New Construction', 'PCCP'),
(39, 'Roads', 'New Construction', 'PCCP');

-- --------------------------------------------------------

--
-- Table structure for table `progress`
--

CREATE TABLE `progress` (
  `projid` varchar(500) NOT NULL,
  `projname` varchar(500) NOT NULL,
  `projmcw` varchar(500) NOT NULL,
  `progdate` date NOT NULL,
  `progrowstart` date NOT NULL,
  `progrowend` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `progtcpstart` date NOT NULL,
  `progtcpend` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `progpipestart` date NOT NULL,
  `progpipeend` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `progpolestart` date NOT NULL,
  `progpoleend` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `projid` varchar(8) NOT NULL,
  `projname` varchar(500) NOT NULL,
  `projclient` varchar(255) NOT NULL,
  `projmanager` varchar(255) NOT NULL,
  `projchecker` varchar(255) NOT NULL,
  `projengineer` varchar(255) NOT NULL,
  `projbudget` decimal(65,2) NOT NULL,
  `projlocation` varchar(255) NOT NULL,
  `projstart` date NOT NULL,
  `projend` date NOT NULL,
  `projmcw` varchar(500) NOT NULL,
  `projdimension` varchar(255) NOT NULL,
  `projdate_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `projend_actual` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`projid`, `projname`, `projclient`, `projmanager`, `projchecker`, `projengineer`, `projbudget`, `projlocation`, `projstart`, `projend`, `projmcw`, `projdimension`, `projdate_added`, `projend_actual`) VALUES
('14DD0058', 'OFF-CARRIAGEWAY IMPVT OF BATANGAS-QUEZON ROAD K0116+663-K0117+582', 'DPWH - Batangas 4th District Engineering Office', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '768228.00', 'Rosario, Batangas', '2015-02-05', '2015-08-05', 'Bridges-Construction-Concrete', '5.60 km', '2018-11-05 07:29:26', '0000-00-00'),
('14DD0031', 'REPLACEMENT OF LAPU-LAPU BRIDGE INCLUDING APPROACHES ALONG IBAAN-SAN JOSE ROAD', 'DPWH - Batangas 4th District Engineering Office', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '13486332.00', 'Ibaan, Batangas', '2014-11-19', '2015-07-17', 'Bridges-Construction-With Bored Piles', '18.00 lm', '2018-11-05 07:00:17', '0000-00-00'),
('14DD0027', 'REHAB. OF MPB', 'DPWH - Batangas 4th District Engineering Office', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '4223009.56', 'Brgy. Poblacion, Ibaan, Batangas', '2015-01-07', '2015-05-07', 'Buildings-Industrial Plant-Low Rise', '1.00 stories', '2018-11-05 07:24:34', '0000-00-00'),
('14DD0058', 'OFF-CARRIAGEWAY IMPVT OF BATANGAS-QUEZON ROAD K0116+663-K0117+582', 'DPWH - Batangas 4th District Engineering Office', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '12461300.00', 'Rosario, Batangas', '2015-02-05', '2015-08-05', 'Flood Control-Hydraulics-Drainage', '919.00 lm', '2018-11-05 07:38:38', '0000-00-00'),
('14DD0031', 'REPLACEMENT OF LAPU-LAPU VRIDGE INCLUDING APPROACHES ALONG IBAAN-SAN JOSE ROAD', 'DPWH - Batangas 4th District Engineering Office', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '5140770.00', 'Ibaan, Batangas', '2014-11-19', '2015-07-17', 'Flood Control-Hydraulics-River Control', '346.14 lm', '2018-11-05 07:14:52', '0000-00-00'),
('14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'DPWH-Region IV-A', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '55756196.40', 'Batangas Province', '2014-10-08', '2015-07-05', 'Roads-New Construction-PCCP', '2.92 km', '2018-11-05 06:49:48', '0000-00-00'),
('14DD0031', 'REPLACEMENT OF LAPU-LAPU BRIDGE INCLUDING APPROACHES ALONG IBAAN-SAN JOSE ROAD', 'DPWH-Batangas 4th District Engineering Office', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '5225810.00', 'Ibaan, Batangas', '2014-11-19', '2015-07-17', 'Roads-Rehabilitation-PCCP', '0.19 km', '2018-11-05 07:17:52', '0000-00-00'),
('00000000', 'TEST.1', 'Test.1', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '9876543210.00', 'Test.1', '2018-11-10', '2018-11-30', 'Bridges-Construction-Concrete', '100 km', '2018-11-10 08:55:48', '0000-00-00'),
('00000000', 'TEST.2', 'TEST.2', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '9876543210.00', 'Taysan', '2018-11-10', '2018-11-30', 'Buildings-Hydraulics-Drainage', '100 km', '2018-11-10 08:59:56', '0000-00-00'),
('00000000', 'TEST.3', 'Test.3', 'John Paul Paulite Chavez', 'Jimuel Paulite Chavez', 'Jerome Paulite Chavez', '9876543210.00', 'Taysan', '2018-11-10', '2018-11-30', 'Buildings-Hydraulics-Drainage', '100 km', '2018-11-10 11:26:59', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `requisition`
--

CREATE TABLE `requisition` (
  `prno` varchar(8) NOT NULL,
  `projchecker` varchar(500) NOT NULL,
  `projdatenow` date NOT NULL,
  `projid` varchar(8) NOT NULL,
  `projname` varchar(500) NOT NULL,
  `projmcw` varchar(500) NOT NULL,
  `prdeptproj` varchar(500) NOT NULL,
  `prdate_need` date NOT NULL,
  `pritem` varchar(500) NOT NULL,
  `prquantity` varchar(500) NOT NULL,
  `printended` varchar(500) NOT NULL,
  `prremarka` varchar(500) NOT NULL,
  `prrequestby` varchar(500) NOT NULL,
  `prnoted` varchar(500) NOT NULL,
  `prapproved` varchar(500) NOT NULL,
  `prremarkb` varchar(500) NOT NULL,
  `projdatetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requisition`
--

INSERT INTO `requisition` (`prno`, `projchecker`, `projdatenow`, `projid`, `projname`, `projmcw`, `prdeptproj`, `prdate_need`, `pritem`, `prquantity`, `printended`, `prremarka`, `prrequestby`, `prnoted`, `prapproved`, `prremarkb`, `projdatetime`) VALUES
('11-11111', 'Jimuel Paulite Chavez', '2018-11-07', '14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '', '2018-11-07', '', '', '', '', 'a', 'a', 'a', 'a', '2018-11-07 13:57:39'),
('22-22222', 'Jimuel Paulite Chavez', '2018-11-07', '14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '', '2018-11-07', '', '', '', '', 'HAHAHAHHA', 'HAHAHAHHA', 'HAHAHAHHA', 'HAHAHAHHA', '2018-11-07 14:03:36'),
('33-33333', 'Jimuel Paulite Chavez', '2018-11-07', '14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '', '2018-11-07', '', '', '', '', 'HAHAHAH', 'HAHAHAH', 'HAHAHAH', 'HAHAHAH', '2018-11-07 14:07:31'),
('44-44444', 'Jimuel Paulite Chavez', '2018-11-11', '14D00023', 'WIDENING OF MANILA-BATANGAS ROAD 2ND L.D. INCLUDING DRAINAGE SYSTEM', 'Roads-New Construction-PCCP', '', '2018-11-14', 'aaaa', '456', 'aaa', 'aaa', 'aaa', 'aaa', 'aaa', 'aaa', '2018-11-11 06:15:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `account_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `offadd` varchar(500) NOT NULL,
  `client` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `first_name`, `middle_name`, `last_name`, `password`, `position`, `email`, `phone`, `address`, `avatar`, `account_date`, `offadd`, `client`) VALUES
(9, 'alyssa', 'Alyssa Joyce', 'Villacorta', 'Mendoza', 'alyssa', 'purchasing officer', '', '', '', 'default.jpg', '2018-11-11 17:05:04', '', ''),
(8, 'donnalyn', 'Donnalyn', 'Jereos', 'Bartolome', 'donnalyn', 'client', 'donnalyn@gmail.com', '09555555555', 'Manila', '003---.gif', '2018-11-11 19:46:15', 'DPWH Batangas City', 'DPWH - Batangas 4th District Engineering Office'),
(3, 'jerome', 'Jerome', 'Paulite', 'Chavez', 'jerome', 'project engineer', 'jerome@gmail.com', '09222222222', 'Pag-asa, Taysan, Batangas', '3297--.jpg', '2018-11-05 06:05:41', '', ''),
(2, 'jimuel', 'Jimuel', 'Paulite', 'Chavez', 'jimuel', 'checker', 'jimuel@gmail.com', '09777777777', 'Pag-asa, Taysan, Batangas', '676792-(2)-.jpg', '2018-11-06 08:40:21', '', ''),
(1, 'jipedoodles', 'John Paul', 'Paulite', 'Chavez', 'codemaster21', 'head manager', 'jopapacha21@gmail.com', '09123456789', 'Pag-asa, Taysan, Batangas', 'default-.jpg', '2018-11-11 03:24:21', '', ''),
(5, 'jobert', 'Jobert', 'De Guzman', 'Gonzales', 'jobert', 'project engineer', 'jobert@gmail.com', '09444444444', 'Bolbok, Batangas City', '20180518_194734--.jpg', '2018-11-05 06:07:43', '', ''),
(4, 'jonel', 'Jonel', 'Bunyi', 'Honor', 'jonel', 'checker', 'jonel@gmail.com', '09333333333', 'Batangas City', '20180518_194656--.jpg', '2018-11-05 06:06:41', '', ''),
(6, 'kier', 'Kier', 'Sy', 'Espiritu', 'kier', 'project manager', 'kier@gmail.com', '09888888888', 'Batangas City', '20180518_194904--.jpg', '2018-11-05 08:26:06', '', ''),
(7, 'noah', 'John', 'Noah', 'Axalan', 'noah', 'project manager', 'noah@gmail.com', '09666666666', 'Batangas', 'default.jpg', '2018-11-11 19:24:30', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mcw`
--
ALTER TABLE `mcw`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD KEY `projid` (`projid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mcw`
--
ALTER TABLE `mcw`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

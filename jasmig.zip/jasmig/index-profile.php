<?php include 'components/authentication.php' ?>
<?php include 'components/session-check-index.php' ?>
<?php require '_database/database.php'; ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/nav/nav.php' ?>

<?php include 'controllers/form/registration.php' ?>
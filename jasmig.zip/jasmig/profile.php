<?php include 'components/authentication.php' ?> 
<?php include 'components/session-check-profile.php' ?>
<?php include 'controllers/base/head.php' ?>
<?php include 'controllers/base/style.php' ?>
<?php include 'controllers/nav/nav.php' ?>

<?php 
    $current_user = $_SESSION['username'];
    $username = mysqli_real_escape_string($database,$_REQUEST['username']);
    $profile_username=$rws['username'];
?>
<?php
    $url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
?>
<div class="profile">
	<div class="row clearfix">
        <div>
            <div>
                <center>
                    <img src="userfiles/avatars/<?php echo $rws['avatar'];?>" class="img-responsive profile-avatar">
                    <h1 class="text-center profile-text profile-name"><?php echo $rws['first_name'];?> <?php echo $rws['middle_name'];?> <?php echo $rws['last_name'];?></h1>
                    <h2 class="text-center profile-text profile-profession"><?php echo $rws['position'];?></h2>
                    <h5 class="text-center"><?php echo $rws['username'];?>; <?php echo $rws['password'];?></h5>
                    <div class="panel panel-default">
                        <div id="panel-element-info" class="panel-collapse collapse in">
                        <br>
                            <p class="text-center profile-title"><i class="fa fa-info"></i> Information</p>
                            <hr>
<?php
    if ($rws['address']){
?>                          <div>
                                <p class="profile-details"><i class="fa fa-info"></i> Address:</p><?php echo $rws['address'];?>
                            </div>
<?php } ?>
<?php
    if ($rws['email']){
?>                          <div>
                                <p class="profile-details"><i class="fa fa-envelope"></i> Email: </p><?php echo $rws['email'];?>
                            </div>
<?php } ?>
<?php
    if ($rws['phone']){
?>                          <div>
                                <p class="profile-details"><i class="fa fa-envelope"></i> Phone: </p><?php echo $rws['phone'];?>
                            </div>
<?php } ?>
                        </div>
                    </div>
                </center>
            </div>
        </div>
    </div>
</div>